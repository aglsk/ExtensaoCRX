// Função debounce para limitar chamadas frequentes
function debounce(func, wait, immediate) {
  let timeout;
  return function () {
    const context = this, args = arguments;
    const later = function () {
      timeout = null;
      if (!immediate) func.apply(context, args);
    };
    const callNow = immediate && !timeout;
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
    if (callNow) func.apply(context, args);
  };
}

// Mostrar notificação
function showNotification(type, title, message) {
  const notification = document.createElement('div');
  notification.className = `notification notification-${type}`;

  const icon = document.createElement('i');
  icon.className = 'icon';

  if (type === 'success') {
    icon.classList.add('fas', 'fa-check-circle');
  } else if (type === 'error') {
    icon.classList.add('fas', 'fa-exclamation-circle');
  } else {
    icon.classList.add('fas', 'fa-info-circle');
  }

  const content = document.createElement('div');
  content.className = 'notification-content';

  const titleEl = document.createElement('h4');
  titleEl.textContent = title;

  const messageEl = document.createElement('p');
  messageEl.textContent = message;

  content.appendChild(titleEl);
  content.appendChild(messageEl);

  notification.appendChild(icon);
  notification.appendChild(content);

  document.body.appendChild(notification);

  setTimeout(() => {
    notification.classList.add('show');
  }, 10);

  setTimeout(() => {
    notification.classList.remove('show');
    setTimeout(() => {
      notification.remove();
    }, 300);
  }, 5000);
}
