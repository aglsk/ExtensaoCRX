// Constantes
const MAX_MESSAGE_LENGTH = 5000;

// Elementos do DOM
const messageForm = document.getElementById('messageForm');
const chatIdInput = document.getElementById('chatId');
const tokenInput = document.getElementById('token');
const messageInput = document.getElementById('message');
const photoOptionSelect = document.getElementById('photoOption');
const photoUrlGroup = document.getElementById('photoUrlGroup');
const photoFileGroup = document.getElementById('photoFileGroup');
const photoUrlInput = document.getElementById('photoUrl');
const photoFileInput = document.getElementById('photoFile');
const fileNameSpan = document.getElementById('fileName');
const charCountSpan = document.getElementById('charCount');
const submitBtn = document.getElementById('submitBtn');
const notificationModal = document.getElementById('notificationModal');

// Estado da aplicação
let isSending = false;

// Inicialização
document.addEventListener('DOMContentLoaded', initApp);

function initApp() {
  loadSavedData();
  setupEventListeners();
  hideAttachmentGroups();
}

function loadSavedData() {
  chrome.storage.sync.get(['chatId', 'token'], (data) => {
    if (data.chatId) chatIdInput.value = data.chatId;
    if (data.token) tokenInput.value = data.token;
  });
}

function setupEventListeners() {
  // Contador de caracteres
  messageInput.addEventListener('input', updateCharCount);
  
  // Opções de anexo
  photoOptionSelect.addEventListener('change', handleAttachmentChange);
  
  // Fechar grupos de anexo
  document.querySelectorAll('.close-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = btn.getAttribute('data-target');
      hideAttachmentGroup(target);
      photoOptionSelect.value = 'none';
    });
  });
  
  // Upload de arquivo
  photoFileInput.addEventListener('change', handleFileUpload);
  
  // Envio do formulário
  messageForm.addEventListener('submit', handleFormSubmit);
  
  // Fechar modal
  document.querySelector('.modal-close-btn').addEventListener('click', closeNotification);
  document.querySelector('.confirm-btn').addEventListener('click', closeNotification);
}

function updateCharCount() {
  const count = messageInput.value.length;
  charCountSpan.textContent = count;
  
  if (count > MAX_MESSAGE_LENGTH * 0.9) {
    charCountSpan.style.color = 'var(--error)';
  } else {
    charCountSpan.style.color = 'var(--gray)';
  }
}

function handleAttachmentChange() {
  const option = photoOptionSelect.value;
  hideAttachmentGroups();
  
  if (option === 'url') {
    photoUrlGroup.style.display = 'block';
  } else if (option === 'file') {
    photoFileGroup.style.display = 'block';
  }
}

function hideAttachmentGroups() {
  photoUrlGroup.style.display = 'none';
  photoFileGroup.style.display = 'none';
}

function hideAttachmentGroup(groupId) {
  document.getElementById(groupId).style.display = 'none';
}

function handleFileUpload() {
  const file = photoFileInput.files[0];
  if (file) {
    fileNameSpan.textContent = file.name;
  } else {
    fileNameSpan.textContent = 'Nenhum arquivo selecionado';
  }
}

async function handleFormSubmit(e) {
  e.preventDefault();
  
  if (isSending) return;
  
  // Validação
  if (!validateForm()) return;
  
  try {
    isSending = true;
    setLoadingState(true);
    
    // Preparar dados
    const formData = prepareFormData();
    
    // Enviar mensagem
    const response = await sendMessage(formData);
    
    if (response.ok) {
      const result = await response.json();
      handleSuccess(result);
    } else {
      const error = await response.json();
      handleError(error);
    }
  } catch (error) {
    handleError(error);
  } finally {
    isSending = false;
    setLoadingState(false);
  }
}

function validateForm() {
  let isValid = true;
  
  // Limpar erros
  document.querySelectorAll('.is-invalid').forEach(el => {
    el.classList.remove('is-invalid');
  });
  
  // Validar Chat ID
  if (!chatIdInput.value.trim()) {
    chatIdInput.classList.add('is-invalid');
    isValid = false;
  }
  
  // Validar Token
  if (!tokenInput.value.trim()) {
    tokenInput.classList.add('is-invalid');
    isValid = false;
  }
  
  // Validar Mensagem
  if (!messageInput.value.trim()) {
    messageInput.classList.add('is-invalid');
    isValid = false;
  } else if (messageInput.value.length > MAX_MESSAGE_LENGTH) {
    messageInput.classList.add('is-invalid');
    showError('A mensagem excede o limite de caracteres.');
    isValid = false;
  }
  
  // Validar Anexo se selecionado
  const attachmentOption = photoOptionSelect.value;
  if (attachmentOption === 'url' && !photoUrlInput.value.trim()) {
    photoUrlInput.classList.add('is-invalid');
    isValid = false;
  } else if (attachmentOption === 'file' && !photoFileInput.files.length) {
    photoFileInput.classList.add('is-invalid');
    isValid = false;
  }
  
  return isValid;
}

function prepareFormData() {
  const formData = new FormData();
  const attachmentOption = photoOptionSelect.value;
  
  // Dados básicos
  formData.append('chat_id', chatIdInput.value.trim());
  
  // Salvar dados
  chrome.storage.sync.set({
    chatId: chatIdInput.value.trim(),
    token: tokenInput.value.trim()
  });
  
  // Com anexo
  if (attachmentOption === 'url') {
    formData.append('photo', photoUrlInput.value.trim());
    formData.append('caption', messageInput.value.trim());
  } else if (attachmentOption === 'file') {
    formData.append('photo', photoFileInput.files[0]);
    formData.append('caption', messageInput.value.trim());
  } else {
    // Apenas texto
    formData.append('text', messageInput.value.trim());
  }
  
  return formData;
}

async function sendMessage(formData) {
  const token = tokenInput.value.trim();
  const attachmentOption = photoOptionSelect.value;
  
  let endpoint;
  if (attachmentOption === 'url' || attachmentOption === 'file') {
    endpoint = `https://api.telegram.org/bot${token}/sendPhoto`;
  } else {
    endpoint = `https://api.telegram.org/bot${token}/sendMessage`;
  }
  
  const headers = {};
  if (attachmentOption !== 'file') {
    headers['Content-Type'] = 'application/x-www-form-urlencoded';
    const params = new URLSearchParams();
    formData.forEach((value, key) => params.append(key, value));
    return await fetch(endpoint, {
      method: 'POST',
      headers,
      body: params
    });
  } else {
    return await fetch(endpoint, {
      method: 'POST',
      body: formData
    });
  }
}

function handleSuccess(result) {
  showNotification('success', 'Mensagem Enviada!', 'Sua mensagem foi enviada com sucesso para o Telegram.');
  resetForm();
}

function handleError(error) {
  console.error('Erro ao enviar mensagem:', error);
  let errorMessage = 'Ocorreu um erro ao enviar a mensagem.';
  
  if (error.description) {
    errorMessage = error.description;
  } else if (error.message) {
    errorMessage = error.message;
  }
  
  showNotification('error', 'Erro ao Enviar', errorMessage);
}

function resetForm() {
  messageInput.value = '';
  photoUrlInput.value = '';
  photoFileInput.value = '';
  fileNameSpan.textContent = 'Nenhum arquivo selecionado';
  photoOptionSelect.value = 'none';
  hideAttachmentGroups();
  updateCharCount();
}

function setLoadingState(isLoading) {
  if (isLoading) {
    submitBtn.classList.add('loading');
    submitBtn.disabled = true;
  } else {
    submitBtn.classList.remove('loading');
    submitBtn.disabled = false;
  }
}

function showNotification(type, title, message) {
  const modal = document.getElementById('notificationModal');
  const icon = modal.querySelector('.modal-icon');
  const titleEl = modal.querySelector('.modal-title');
  const messageEl = modal.querySelector('.modal-body p');
  
  // Atualizar conteúdo
  titleEl.textContent = title;
  messageEl.textContent = message;
  
  // Atualizar ícone e cores
  icon.className = 'modal-icon';
  icon.classList.add('fas');
  
  if (type === 'success') {
    icon.classList.add('fa-check-circle', 'success');
  } else if (type === 'error') {
    icon.classList.add('fa-exclamation-circle', 'error');
  } else {
    icon.classList.add('fa-info-circle', 'warning');
  }
  
  // Mostrar modal
  modal.classList.add('active');
}

function closeNotification() {
  notificationModal.classList.remove('active');
}