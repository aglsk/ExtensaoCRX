document.addEventListener('DOMContentLoaded', function() {
  // Carrega mensagens salvas
  loadSavedMessages();
  
  // Configura eventos
  setupEventListeners();
});

function loadSavedMessages() {
  chrome.storage.sync.get(['customMessages'], function(result) {
    if (result.customMessages && result.customMessages.length > 0) {
      renderMessages(result.customMessages);
    } else {
      // Mensagens padrão
      const defaultMessages = [
        "Olá, Bom Dia!",
        "Olá, Boa Tarde!",
		"Olá, Boa Noite!",
        "Como Podemos Ajudar ?",
        "Obrigado pela sua preferência e confiança",
        "Confirmando nosso agendamento"
      ];
      renderMessages(defaultMessages);
    }
  });
}

function renderMessages(messages) {
  const messageList = document.querySelector('.message-list');
  messageList.innerHTML = '';
  
  messages.forEach((message, index) => {
    const messageItem = document.createElement('div');
    messageItem.className = 'message-item';
    messageItem.innerHTML = `
      <div class="message-content">${message}</div>
      <button class="send-btn" data-message="${escapeHtml(message)}" data-index="${index}">
        <i class="fas fa-paper-plane"></i> Enviar
      </button>
      <button class="delete-btn" data-index="${index}">
        <i class="fas fa-trash"></i>
      </button>
    `;
    messageList.appendChild(messageItem);
  });
  
  setupSendButtons();
  setupDeleteButtons();
}

function setupEventListeners() {
  // Botão de adicionar mensagem
  document.getElementById('addBtn').addEventListener('click', addNewMessage);
  
  // Configura botões
  setupSendButtons();
  setupDeleteButtons();
}

function setupSendButtons() {
  document.querySelectorAll('.send-btn').forEach(button => {
    button.addEventListener('click', function() {
      const message = this.getAttribute('data-message');
      sendMessageToWhatsApp(message);
    });
  });
}

function setupDeleteButtons() {
  document.querySelectorAll('.delete-btn').forEach(button => {
    button.addEventListener('click', function() {
      const index = parseInt(this.getAttribute('data-index'));
      deleteMessage(index);
    });
  });
}

function addNewMessage() {
  const newMessageInput = document.getElementById('newMessage');
  const message = newMessageInput.value.trim();
  
  if (message === '') {
    showAlert('Por favor, digite uma mensagem');
    return;
  }
  
  chrome.storage.sync.get(['customMessages'], function(result) {
    const customMessages = result.customMessages || [];
    customMessages.push(message);
    
    chrome.storage.sync.set({ customMessages }, function() {
      newMessageInput.value = '';
      renderMessages(customMessages);
      showAlert('Mensagem adicionada com sucesso!', 'success');
    });
  });
}

function deleteMessage(index) {
  chrome.storage.sync.get(['customMessages'], function(result) {
    const customMessages = result.customMessages || [];
    if (index >= 0 && index < customMessages.length) {
      customMessages.splice(index, 1);
      chrome.storage.sync.set({ customMessages }, function() {
        renderMessages(customMessages);
        showAlert('Mensagem removida!', 'success');
      });
    }
  });
}

function sendMessageToWhatsApp(message) {
  chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
    const activeTab = tabs[0];
    
    if (activeTab.url.includes('web.whatsapp.com')) {
      // Mostra status de carregamento
      const sendBtn = document.querySelector(`.send-btn[data-message="${escapeHtml(message)}"]`);
      if (sendBtn) {
        sendBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Enviando';
        sendBtn.disabled = true;
      }
      
      chrome.scripting.executeScript({
        target: { tabId: activeTab.id },
        function: injectMessage,
        args: [message]
      }, (results) => {
        // Restaura o botão
        if (sendBtn) {
          sendBtn.innerHTML = '<i class="fas fa-paper-plane"></i> Enviar';
          sendBtn.disabled = false;
        }
        
        if (chrome.runtime.lastError) {
          showAlert('Erro ao enviar mensagem: ' + chrome.runtime.lastError.message, 'error');
          return;
        }
        
        if (results && results[0] && results[0].result === 'success') {
          showAlert('Mensagem enviada com sucesso!', 'success');
        } else {
          showAlert('Não foi possível enviar a mensagem', 'error');
        }
      });
    } else {
      showAlert('Por favor, abra o WhatsApp Web primeiro', 'error');
    }
  });
}

function injectMessage(message) {
  try {
    const caixa = document.querySelector('div[contenteditable="true"][aria-label="Digite uma mensagem"]');
    if (!caixa) return 'no-input';

    caixa.focus();
    document.execCommand("insertText", false, message);
    caixa.dispatchEvent(new InputEvent("input", { bubbles: true }));

    setTimeout(() => {
      const event = new KeyboardEvent("keydown", {
        bubbles: true,
        cancelable: true,
        key: "Enter",
        code: "Enter",
        keyCode: 13,
        which: 13
      });
      caixa.dispatchEvent(event);
    }, 300);

    return 'success';
  } catch (error) {
    console.error('Erro ao enviar mensagem:', error);
    return 'error';
  }
}

function findMessageInput() {
  // Encontra o elemento exato do input de mensagem
  const inputs = document.querySelectorAll('p.selectable-text.copyable-text');
  for (const input of inputs) {
    if (input.getAttribute('contenteditable') === 'true') {
      return input;
    }
  }
  return null;
}

function findSendButton() {
  // Encontra o botão de enviar
  const buttons = document.querySelectorAll('button[data-testid="compose-btn-send"]');
  return buttons.length > 0 ? buttons[0] : null;
}

function getActiveChatTitle() {
  // Encontra o título da conversa ativa
  const titles = document.querySelectorAll('span[data-testid="conversation-info-header-chat-title"]');
  return titles.length > 0 ? titles[0].textContent.trim() : null;
}

function showAlert(message, type = 'error') {
  const alertDiv = document.createElement('div');
  alertDiv.className = `alert alert-${type}`;
  alertDiv.textContent = message;
  
  document.body.appendChild(alertDiv);
  setTimeout(() => alertDiv.remove(), 3000);
}

function escapeHtml(unsafe) {
  return unsafe
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}